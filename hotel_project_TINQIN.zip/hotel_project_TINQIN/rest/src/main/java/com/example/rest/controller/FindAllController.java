package com.example.rest.controller;

public class FindAllController {

    
}
