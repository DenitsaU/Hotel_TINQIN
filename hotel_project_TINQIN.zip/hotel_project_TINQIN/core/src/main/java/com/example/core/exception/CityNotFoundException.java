package com.example.core.exception;

public class CityNotFoundException extends RuntimeException{
}
