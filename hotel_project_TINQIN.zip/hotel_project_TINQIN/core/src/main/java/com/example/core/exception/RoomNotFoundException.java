package com.example.core.exception;

public class RoomNotFoundException extends RuntimeException{
}
