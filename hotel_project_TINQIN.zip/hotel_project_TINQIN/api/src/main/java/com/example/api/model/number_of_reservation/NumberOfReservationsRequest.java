package com.example.api.model.number_of_reservation;

import com.example.api.base.OperationInput;
import lombok.*;

@AllArgsConstructor
//@NoArgsConstructor
@Setter(AccessLevel.PRIVATE)
@Getter
public class NumberOfReservationsRequest implements OperationInput {
    //private Integer hotelID;
  //  private String sorted;
}
