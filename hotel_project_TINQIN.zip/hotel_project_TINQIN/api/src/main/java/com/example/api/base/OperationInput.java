package com.example.api.base;

public interface OperationInput {
}
