package com.example.api.base;

public interface OperationResult {
}
