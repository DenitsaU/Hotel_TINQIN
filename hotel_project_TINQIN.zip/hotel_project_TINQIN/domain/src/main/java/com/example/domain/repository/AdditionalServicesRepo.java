package com.example.domain.repository;

import com.example.domain.entity.AdditionalServices;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdditionalServicesRepo extends JpaRepository<AdditionalServices,Integer> {
}
